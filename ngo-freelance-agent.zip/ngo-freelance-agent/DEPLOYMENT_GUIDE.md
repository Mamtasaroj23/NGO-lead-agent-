# Deployment Guide: Autonomous AI Freelance Lead Agent

This guide explains how to deploy your AI Agent so it runs 24/7 in the cloud without needing your laptop to stay on, and how to verify/check it after deployment.

---

## 🚀 Option 1: GitHub Actions (Recommended — 100% Free Cloud Runner)

This is the easiest and most reliable way to run the agent in the cloud. GitHub will automatically wake up every 3 hours, scan all NGO portals, generate AI proposals, and send you push notifications on Telegram.

### Step-by-Step Setup:
1. **Initialize Git & Push to GitHub**:
   In PowerShell, run:
   ```powershell
   cd C:\Users\LENOVO\.gemini\antigravity\scratch\ngo-freelance-agent
   git init
   git add .
   git commit -m "Initial commit"
   # Create a new repository on https://github.com/new (make it Private)
   git remote add origin https://github.com/<your-username>/<your-repo-name>.git
   git branch -M main
   git push -u origin main
   ```

2. **Add Your Keys as GitHub Secrets**:
   - Go to your repository on GitHub.
   - Click **Settings** (gear icon) &rarr; **Secrets and variables** &rarr; **Actions**.
   - Click **New repository secret** and add:
     - `TELEGRAM_BOT_TOKEN` = `your_bot_token`
     - `TELEGRAM_CHAT_ID` = `your_chat_id`
     - `GEMINI_API_KEY` = `your_gemini_key` (optional)

### How to Check After Deployment:
- Go to the **Actions** tab on your GitHub repository.
- You will see the workflow **"NGO Freelance Lead Hunter Agent"**.
- Click **"Run workflow"** &rarr; **"Run workflow"** button to trigger an immediate run.
- Click on the running job to watch real-time cloud logs!
- Check your Telegram on your phone — you will receive the lead alert cards instantly!

---

## 🌐 Option 2: Render.com (Free Web Dashboard on Public URL)

If you want your web dashboard accessible from anywhere (mobile, office, home) via a live public link like `https://my-lead-agent.onrender.com`.

### Step-by-Step Setup:
1. Go to [Render.com](https://render.com) and sign up / log in with your GitHub account.
2. Click **New +** &rarr; **Web Service**.
3. Connect your GitHub repository (`ngo-freelance-agent`).
4. Set the following settings:
   - **Name**: `ngo-lead-agent`
   - **Language**: `Python 3`
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `python web_server.py`
   - **Instance Type**: `Free`
5. Under **Environment Variables**, add:
   - `TELEGRAM_BOT_TOKEN`
   - `TELEGRAM_CHAT_ID`
   - `GEMINI_API_KEY`
6. Click **Create Web Service**.

### How to Check After Deployment:
- Render will build and deploy your container in ~2 minutes.
- Once it says **"Live"**, click the public URL (e.g., `https://ngo-lead-agent.onrender.com`).
- You will see your dark-mode Lead Portal with all discovered opportunities!
- Click **"Scan For New Leads"** or **"Test Telegram"** right in your browser to verify it.

---

## 💻 Option 3: Local Background Auto-Run (On your Windows PC)

If you want it to run silently on your computer:
1. Double-click `run_background.vbs`.
2. The agent runs silently without opening any black command prompt window.
3. Open `http://localhost:5000` anytime to view the live dashboard.
4. Check logs in `storage/logs/agent.log`.
