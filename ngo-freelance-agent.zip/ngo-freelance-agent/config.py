import os
from pathlib import Path
from dotenv import load_dotenv

# Base directory
BASE_DIR = Path(__file__).resolve().parent

# Load environment variables from .env if present
load_dotenv(BASE_DIR / '.env')

# User Freelancing Profile
USER_PROFILE = {
    "name": os.getenv("USER_NAME", "Data & Business Analyst"),
    "role": "Data Analyst & Business Analyst",
    "primary_skills": [
        "Advanced Excel",
        "Excel AI & Automation",
        "Power Query",
        "Power BI",
        "SQL",
        "Python",
        "Data Cleaning & ETL",
        "Interactive Dashboards & KPI Reporting",
        "Business Analysis & Workflow Optimization"
    ],
    "experience_goal": "Pro-bono freelancing for non-profits and NGOs to help organize data, build visual dashboards, and streamline reporting for good causes while building real-world portfolio case studies.",
    "offer_summary": "100% Free / Pro-Bono Data Analysis & Dashboard Services"
}

# Relevant Keywords for matching NGO needs
TARGET_KEYWORDS = [
    "data", "excel", "spreadsheet", "power bi", "powerbi", "sql", "python",
    "dashboard", "reporting", "analytics", "analyst", "database", "metrics",
    "business analysis", "automation", "survey", "donor", "impact", "tracking",
    "visualization", "clean data", "insights", "kpi", "crm", "google sheets"
]

# API Keys & Auth Configuration
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "").strip()
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "").strip()

# Scheduling configuration (minutes between scans)
SCAN_INTERVAL_MINUTES = int(os.getenv("SCAN_INTERVAL_MINUTES", "60"))

# Database & Reports Paths
DB_PATH = BASE_DIR / "storage" / "leads.db"
REPORTS_DIR = BASE_DIR / "reports"
LOGS_DIR = BASE_DIR / "storage" / "logs"

# Ensure directories exist
DB_PATH.parent.mkdir(parents=True, exist_ok=True)
REPORTS_DIR.mkdir(parents=True, exist_ok=True)
LOGS_DIR.mkdir(parents=True, exist_ok=True)
