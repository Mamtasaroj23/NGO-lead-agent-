import json
import logging
import requests
from typing import Dict, Any, Tuple
from config import GEMINI_API_KEY, USER_PROFILE, TARGET_KEYWORDS

logger = logging.getLogger(__name__)

class AIEvaluator:
    """AI Engine using Google Gemini (with smart offline heuristic fallback)
    to match opportunities to Data & Business Analyst skills and write pro-bono pitches."""

    def __init__(self, api_key: str = GEMINI_API_KEY):
        self.api_key = api_key.strip()
        self.gemini_url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={self.api_key}"

    def analyze_lead(self, lead: Dict[str, Any]) -> Tuple[int, str]:
        """Analyze lead relevance and craft a tailored pro-bono proposal pitch."""
        # Check if Gemini API key is configured
        if self.api_key and len(self.api_key) > 15:
            try:
                score, pitch = self._analyze_with_gemini(lead)
                if score is not None and pitch:
                    return score, pitch
            except Exception as e:
                logger.warning(f"Gemini API analysis failed: {e}. Falling back to heuristic engine.")

        # Smart fallback heuristic engine
        return self._heuristic_analysis(lead)

    def _analyze_with_gemini(self, lead: Dict[str, Any]) -> Tuple[int, str]:
        """Call Google Gemini 1.5 Flash API to evaluate match and generate outreach pitch."""
        skills_str = ", ".join(USER_PROFILE["primary_skills"])
        user_role = USER_PROFILE["role"]

        prompt = f"""
You are an expert career and proposal consultant assisting a {user_role}.
The analyst's primary skills are: {skills_str}.
Goal: Offer 100% FREE / PRO-BONO freelancing services to NGOs and non-profits to help them with data analysis, Excel automation, Power BI dashboards, and reporting while gaining hands-on portfolio experience.

Opportunity Details:
- Title: {lead.get('title')}
- Organization: {lead.get('organization')}
- Cause: {lead.get('cause')}
- Description: {lead.get('description')}

Task:
1. Determine a Match Score from 0 to 100 indicating how well this project fits a Data Analyst / Business Analyst (Excel, Power BI, SQL, Python, automation, reporting, metrics, data cleanup).
2. Write a warm, professional, respectful pro-bono outreach pitch message (under 180 words) addressed to the NGO. Clearly state:
   - Appreciation for their mission.
   - Specific ways you can solve their problem (mentioning Advanced Excel, Power Query, Power BI, or Python).
   - That you are offering this completely free / pro-bono to support their cause and build your portfolio.
   - An invitation for a quick 15-minute chat or to share their sample data.

Output strictly valid JSON with this format:
{{
  "match_score": 85,
  "pitch_draft": "Your personalized pitch text here"
}}
"""
        payload = {
            "contents": [
                {
                    "parts": [{"text": prompt}]
                }
            ],
            "generationConfig": {
                "temperature": 0.3,
                "responseMimeType": "application/json"
            }
        }

        res = requests.post(self.gemini_url, json=payload, timeout=20)
        if res.status_code == 200:
            data = res.json()
            text_response = data["candidates"][0]["content"]["parts"][0]["text"]
            result = json.loads(text_response)
            return int(result.get("match_score", 70)), result.get("pitch_draft", "").strip()
        else:
            raise RuntimeError(f"Gemini API returned status {res.status_code}: {res.text}")

    def _heuristic_analysis(self, lead: Dict[str, Any]) -> Tuple[int, str]:
        """Intelligent offline matching and pitch generator when API key is not present."""
        text = f"{lead.get('title', '')} {lead.get('description', '')} {lead.get('cause', '')}".lower()
        
        # Calculate skill relevance
        matched_keywords = [kw for kw in TARGET_KEYWORDS if kw in text]
        
        # Base score based on keywords
        base_score = 50
        keyword_bonus = min(len(matched_keywords) * 10, 45)
        match_score = min(base_score + keyword_bonus, 98)

        # High value tags
        has_excel = any(k in text for k in ["excel", "spreadsheet", "google sheets"])
        has_bi = any(k in text for k in ["power bi", "dashboard", "visualization", "reporting"])
        has_database = any(k in text for k in ["database", "sql", "crm", "donor"])
        has_automation = any(k in text for k in ["automation", "python", "power query", "clean"])

        tools_highlight = []
        if has_excel:
            tools_highlight.append("Advanced Excel & Power Query for clean data modeling")
        if has_bi:
            tools_highlight.append("interactive Power BI dashboards for KPI tracking")
        if has_database:
            tools_highlight.append("SQL database structuring and donor analysis")
        if has_automation or not tools_highlight:
            tools_highlight.append("Python and Excel AI automation to eliminate manual repetitive work")

        tools_text = " and ".join(tools_highlight[:2])

        org = lead.get('organization') or 'Team'
        title = lead.get('title') or 'your project'

        pitch = (
            f"Dear {org} Team,\n\n"
            f"I came across your initiative regarding '{title}' and was truly inspired by the work you do for {lead.get('cause', 'your cause')}.\n\n"
            f"I am a Data & Business Analyst specializing in {tools_text}. "
            f"I am offering my services 100% pro-bono (free of charge) because I want to give back to impactful non-profits while building real-world case studies for my professional portfolio.\n\n"
            f"I would love to help you organize your data, streamline your reporting, and create visual dashboards so your team can make fast, data-driven decisions with zero hassle.\n\n"
            f"Would you be open to a quick 10-minute introductory call this week to discuss how I can assist you?\n\n"
            f"Warm regards,\n"
            f"{USER_PROFILE.get('name', 'Freelance Data Analyst')}\n"
            f"Data & Business Analyst (Pro-Bono Contributor)"
        )

        return match_score, pitch
