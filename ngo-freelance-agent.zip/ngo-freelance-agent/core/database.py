import sqlite3
import datetime
from pathlib import Path
from typing import List, Dict, Optional, Any
from config import DB_PATH

class LeadDatabase:
    """SQLite Database manager for tracking discovered leads, pitches, and notification status."""
    
    def __init__(self, db_path: Path = DB_PATH):
        self.db_path = str(db_path)
        self.init_db()

    def _get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def init_db(self):
        """Initialize database schema with tables and indexes."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS leads (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    unique_id TEXT UNIQUE NOT NULL,
                    source TEXT NOT NULL,
                    title TEXT NOT NULL,
                    organization TEXT,
                    cause TEXT,
                    description TEXT,
                    url TEXT,
                    contact_person TEXT,
                    match_score INTEGER DEFAULT 0,
                    pitch_draft TEXT,
                    status TEXT DEFAULT 'new',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    notified_at TIMESTAMP
                )
            """)
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_leads_unique ON leads(unique_id)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_leads_status ON leads(status)")
            conn.commit()

    def lead_exists(self, unique_id: str) -> bool:
        """Check if a lead has already been recorded."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT 1 FROM leads WHERE unique_id = ?", (unique_id,))
            return cursor.fetchone() is not None

    def save_lead(self, lead: Dict[str, Any]) -> Optional[int]:
        """Save a new lead if it does not already exist."""
        unique_id = lead.get("unique_id") or lead.get("url")
        if not unique_id or self.lead_exists(unique_id):
            return None

        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO leads (
                    unique_id, source, title, organization, cause,
                    description, url, contact_person, match_score,
                    pitch_draft, status, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'new', CURRENT_TIMESTAMP)
            """, (
                unique_id,
                lead.get("source", "Unknown"),
                lead.get("title", "Untitled Opportunity"),
                lead.get("organization", "Non-Profit Organization"),
                lead.get("cause", "General"),
                lead.get("description", ""),
                lead.get("url", ""),
                lead.get("contact_person", ""),
                lead.get("match_score", 0),
                lead.get("pitch_draft", ""),
            ))
            conn.commit()
            return cursor.lastrowid

    def update_ai_analysis(self, lead_id: int, match_score: int, pitch_draft: str):
        """Update match score and generated outreach pitch for a lead."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE leads
                SET match_score = ?, pitch_draft = ?
                WHERE id = ?
            """, (match_score, pitch_draft, lead_id))
            conn.commit()

    def get_unnotified_leads(self, min_score: int = 50, limit: int = 15) -> List[Dict[str, Any]]:
        """Fetch leads that have not been sent via notification yet, sorted by match score."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT * FROM leads
                WHERE notified_at IS NULL AND match_score >= ?
                ORDER BY match_score DESC, created_at DESC
                LIMIT ?
            """, (min_score, limit))
            return [dict(row) for row in cursor.fetchall()]

    def mark_as_notified(self, lead_id: int):
        """Mark a lead as notified with current timestamp."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE leads
                SET notified_at = CURRENT_TIMESTAMP, status = 'notified'
                WHERE id = ?
            """, (lead_id,))
            conn.commit()

    def get_all_leads(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Retrieve recent leads for reports and dashboard."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT * FROM leads
                ORDER BY created_at DESC
                LIMIT ?
            """, (limit,))
            return [dict(row) for row in cursor.fetchall()]

    def get_stats(self) -> Dict[str, Any]:
        """Get summary statistics of discovered leads."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM leads")
            total = cursor.fetchone()[0]

            cursor.execute("SELECT COUNT(*) FROM leads WHERE notified_at IS NOT NULL")
            notified = cursor.fetchone()[0]

            cursor.execute("SELECT COUNT(*) FROM leads WHERE match_score >= 80")
            high_match = cursor.fetchone()[0]

            cursor.execute("SELECT source, COUNT(*) FROM leads GROUP BY source")
            by_source = dict(cursor.fetchall())

            return {
                "total_leads": total,
                "notified_leads": notified,
                "high_match_leads": high_match,
                "sources": by_source
            }
