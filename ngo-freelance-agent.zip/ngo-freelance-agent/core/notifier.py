import logging
import requests
from typing import Dict, Any, List
from pathlib import Path
from config import TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID, REPORTS_DIR

logger = logging.getLogger(__name__)

class TelegramNotifier:
    """Delivers rich push notifications and pitch drafts directly to your Telegram chat."""

    def __init__(self, bot_token: str = TELEGRAM_BOT_TOKEN, chat_id: str = TELEGRAM_CHAT_ID):
        self.bot_token = bot_token.strip()
        self.chat_id = chat_id.strip()
        self.api_base = f"https://api.telegram.org/bot{self.bot_token}"

    def is_configured(self) -> bool:
        """Check if Telegram credentials have been filled in."""
        return bool(self.bot_token and self.chat_id and ":" in self.bot_token)

    def test_connection(self) -> Dict[str, Any]:
        """Test if the Telegram bot token and chat ID are valid and can send messages."""
        if not self.is_configured():
            return {
                "ok": False,
                "error": "Telegram Bot Token or Chat ID is missing in .env. Bot tokens look like '123456789:ABC...'"
            }
        try:
            # 1. Verify bot info
            me_res = requests.get(f"{self.api_base}/getMe", timeout=10)
            if me_res.status_code != 200:
                return {"ok": False, "error": f"Bot token rejected by Telegram: {me_res.text}"}
            bot_info = me_res.json().get("result", {})

            import html
            bot_name = html.escape(bot_info.get('first_name', 'Bot'))
            bot_user = html.escape(bot_info.get('username', ''))

            # 2. Send greeting test message
            msg = (
                f"🤖 <b>Freelance AI Agent Connected Successfully!</b>\n\n"
                f"Bot Name: @{bot_user}\n"
                f"Target Profile: <b>Data &amp; Business Analyst</b>\n"
                f"Skills: Advanced Excel, Power BI, SQL, Python, Automation\n\n"
                f"✅ You will now receive self-messages whenever new NGO opportunities and custom outreach pitches are found!"
            )
            send_res = requests.post(
                f"{self.api_base}/sendMessage",
                json={
                    "chat_id": self.chat_id,
                    "text": msg,
                    "parse_mode": "HTML"
                },
                timeout=10
            )
            if send_res.status_code == 200:
                return {"ok": True, "bot_username": bot_info.get("username")}
            else:
                return {
                    "ok": False,
                    "error": f"Failed to send test message: {send_res.text}."
                }
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def send_lead_notification(self, lead: Dict[str, Any]) -> bool:
        """Format and send a single lead card with pitch draft to Telegram."""
        if not self.is_configured():
            logger.info(f"[TELEGRAM NOT CONFIGURED] Would send lead: {lead.get('title')} ({lead.get('organization')})")
            return False

        import html
        title = html.escape(lead.get('title', 'New Project'))
        org = html.escape(lead.get('organization', 'Non-profit Organization'))
        cause = html.escape(lead.get('cause', 'Community'))
        score = lead.get('match_score', 0)
        source = html.escape(lead.get('source', 'Web'))
        url = lead.get('url', '')
        desc = html.escape(lead.get('description', '')[:220])
        pitch = html.escape(lead.get('pitch_draft', ''))

        message = (
            f"🌟 <b>NEW FREELANCE OPPORTUNITY</b>\n"
            f"━━━━━━━━━━━━━━━━━━━\n"
            f"🏢 <b>NGO:</b> {org}\n"
            f"🎯 <b>Project:</b> {title}\n"
            f"🏷️ <b>Cause / Domain:</b> {cause}\n"
            f"📊 <b>Skill Match:</b> <code>{score}%</code> (Data &amp; Business Analyst)\n"
            f"🌐 <b>Source:</b> {source}\n\n"
            f"📝 <b>Description:</b>\n"
            f"<i>{desc}...</i>\n\n"
            f"💌 <b>Ready-to-Send Outreach Pitch (Tap &amp; Copy):</b>\n"
            f"<pre>{pitch}</pre>\n\n"
            f"🔗 <a href=\"{url}\">Click Here to View / Apply on {source}</a>"
        )

        try:
            res = requests.post(
                f"{self.api_base}/sendMessage",
                json={
                    "chat_id": self.chat_id,
                    "text": message,
                    "parse_mode": "HTML",
                    "disable_web_page_preview": False
                },
                timeout=12
            )
            if res.status_code == 200:
                logger.info(f"Successfully notified Telegram about lead: {title}")
                return True
            else:
                logger.error(f"Telegram notification error: {res.text}")
                return False
        except Exception as e:
            logger.error(f"Error sending Telegram notification: {e}")
            return False


def generate_html_dashboard(leads: List[Dict[str, Any]], stats: Dict[str, Any]) -> Path:
    """Generate a clean visual HTML dashboard to view all leads, match scores, and pitches in any browser."""
    html_file = REPORTS_DIR / "leads_dashboard.html"

    cards_html = ""
    for l in leads:
        score_color = "#10b981" if l.get('match_score', 0) >= 80 else ("#f59e0b" if l.get('match_score', 0) >= 60 else "#6b7280")
        pitch_escaped = (l.get('pitch_draft') or '').replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
        desc_escaped = (l.get('description') or '').replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
        
        cards_html += f"""
        <div class="card">
            <div class="card-header">
                <div>
                    <span class="source-badge">{l.get('source')}</span>
                    <span class="score-badge" style="background-color: {score_color}">{l.get('match_score')}% Match</span>
                    <h2 class="project-title">{l.get('title')}</h2>
                    <h3 class="org-name">🏢 {l.get('organization')} &bull; <span class="cause">{l.get('cause')}</span></h3>
                </div>
                <a href="{l.get('url')}" target="_blank" class="apply-btn">View Opportunity &rarr;</a>
            </div>
            
            <p class="desc">{desc_escaped}</p>

            <div class="pitch-container">
                <div class="pitch-header">
                    <span>💌 Tailored Pro-Bono Proposal Pitch</span>
                    <button class="copy-btn" onclick="navigator.clipboard.writeText(this.nextElementSibling.innerText); this.innerText='Copied!'; setTimeout(()=>this.innerText='Copy Pitch', 2000)">Copy Pitch</button>
                    <div style="display:none">{pitch_escaped}</div>
                </div>
                <pre class="pitch-text">{pitch_escaped}</pre>
            </div>
            <div class="footer-info">Discovered on: {l.get('created_at')} | Status: {l.get('status')}</div>
        </div>
        """

    html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Freelance Leads Dashboard - Data & Business Analyst</title>
    <style>
        :root {{
            --bg: #0f172a;
            --card-bg: #1e293b;
            --text-main: #f8fafc;
            --text-sub: #94a3b8;
            --accent: #38bdf8;
            --border: #334155;
        }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
            background-color: var(--bg);
            color: var(--text-main);
            margin: 0;
            padding: 24px;
        }}
        .container {{
            max-width: 1000px;
            margin: 0 auto;
        }}
        header {{
            margin-bottom: 28px;
            border-bottom: 1px solid var(--border);
            padding-bottom: 20px;
        }}
        h1 {{
            margin: 0 0 8px 0;
            font-size: 26px;
            color: #38bdf8;
        }}
        .sub-header {{
            color: var(--text-sub);
            font-size: 15px;
            margin: 0;
        }}
        .stats-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 16px;
            margin-bottom: 30px;
        }}
        .stat-card {{
            background: var(--card-bg);
            border: 1px solid var(--border);
            border-radius: 10px;
            padding: 16px;
            text-align: center;
        }}
        .stat-val {{
            font-size: 28px;
            font-weight: bold;
            color: #38bdf8;
        }}
        .stat-label {{
            color: var(--text-sub);
            font-size: 13px;
            margin-top: 4px;
        }}
        .card {{
            background: var(--card-bg);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 22px;
            margin-bottom: 20px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        }}
        .card-header {{
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 16px;
            margin-bottom: 12px;
        }}
        .source-badge {{
            background: #3b82f6;
            color: white;
            font-size: 11px;
            font-weight: 600;
            padding: 3px 8px;
            border-radius: 999px;
            text-transform: uppercase;
        }}
        .score-badge {{
            color: white;
            font-size: 11px;
            font-weight: 600;
            padding: 3px 8px;
            border-radius: 999px;
        }}
        .project-title {{
            font-size: 20px;
            margin: 8px 0 4px 0;
            color: #f1f5f9;
        }}
        .org-name {{
            font-size: 14px;
            font-weight: normal;
            color: #cbd5e1;
            margin: 0;
        }}
        .cause {{
            color: #94a3b8;
        }}
        .apply-btn {{
            background: #2563eb;
            color: white;
            padding: 10px 18px;
            border-radius: 8px;
            text-decoration: none;
            font-size: 14px;
            font-weight: 600;
            white-space: nowrap;
            display: inline-block;
            transition: background 0.2s;
        }}
        .apply-btn:hover {{
            background: #1d4ed8;
        }}
        .desc {{
            color: #cbd5e1;
            font-size: 14px;
            line-height: 1.5;
            margin: 12px 0 16px 0;
        }}
        .pitch-container {{
            background: #0f172a;
            border: 1px solid #334155;
            border-radius: 8px;
            padding: 14px;
        }}
        .pitch-header {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 8px;
            font-size: 13px;
            font-weight: 600;
            color: #38bdf8;
        }}
        .copy-btn {{
            background: #334155;
            color: #f8fafc;
            border: none;
            padding: 4px 10px;
            border-radius: 5px;
            font-size: 12px;
            cursor: pointer;
        }}
        .copy-btn:hover {{
            background: #475569;
        }}
        .pitch-text {{
            white-space: pre-wrap;
            font-family: inherit;
            font-size: 13px;
            color: #e2e8f0;
            margin: 0;
            line-height: 1.5;
        }}
        .footer-info {{
            font-size: 11px;
            color: #64748b;
            margin-top: 14px;
        }}
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>🌟 Pro-Bono Freelance Leads for Non-Profits</h1>
            <p class="sub-header">Target Role: <strong>Data Analyst &amp; Business Analyst</strong> (Advanced Excel, Power BI, SQL, Python, Automation)</p>
        </header>

        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-val">{stats.get('total_leads', 0)}</div>
                <div class="stat-label">Total Leads Discovered</div>
            </div>
            <div class="stat-card">
                <div class="stat-val">{stats.get('high_match_leads', 0)}</div>
                <div class="stat-label">High Skill Match (80%+)</div>
            </div>
            <div class="stat-card">
                <div class="stat-val">{stats.get('notified_leads', 0)}</div>
                <div class="stat-label">Notified to Telegram</div>
            </div>
        </div>

        <div class="leads-list">
            {cards_html if cards_html else '<p style="text-align:center; color:#94a3b8;">No leads discovered yet. Run the scanner to pull new opportunities!</p>'}
        </div>
    </div>
</body>
</html>
"""
    with open(html_file, "w", encoding="utf-8") as f:
        f.write(html_content)

    return html_file
