import sys
import time
import argparse
import logging
from pathlib import Path
from typing import List, Dict, Any

# Ensure UTF-8 output on Windows consoles
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')
if hasattr(sys.stderr, 'reconfigure'):
    sys.stderr.reconfigure(encoding='utf-8')

from config import (
    BASE_DIR, LOGS_DIR, REPORTS_DIR,
    SCAN_INTERVAL_MINUTES, TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID
)
from core.database import LeadDatabase
from core.ai_evaluator import AIEvaluator
from core.notifier import TelegramNotifier, generate_html_dashboard
from scrapers.catchafire_scraper import CatchafireScraper
from scrapers.idealist_scraper import IdealistScraper
from scrapers.ngodarpan_scraper import NGODarpanScraper

# Configure logging to both console and file
log_file = LOGS_DIR / "agent.log"
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler(log_file, encoding="utf-8")
    ]
)
logger = logging.getLogger("FreelanceAIAgent")


class FreelanceAIAgent:
    """Autonomous AI Agent that scans non-profit portals, evaluates data/business analyst
    opportunities, crafts tailored outreach proposals, and sends Telegram push alerts."""

    def __init__(self):
        self.db = LeadDatabase()
        self.ai = AIEvaluator()
        self.notifier = TelegramNotifier()
        self.scrapers = [
            CatchafireScraper(),
            IdealistScraper(),
            NGODarpanScraper()
        ]

    def run_cycle(self) -> Dict[str, Any]:
        """Executes one complete discovery, analysis, and notification cycle."""
        logger.info("=" * 60)
        logger.info("🚀 Starting freelance lead scan cycle...")
        logger.info("Target: Data Analyst & Business Analyst Pro-Bono Opportunities")
        logger.info("=" * 60)

        total_scraped = 0
        new_leads_saved = 0
        notified_count = 0

        # Step 1: Collect opportunities from all scrapers
        all_raw_opportunities: List[Dict[str, Any]] = []
        for scraper in self.scrapers:
            try:
                opps = scraper.fetch_opportunities()
                all_raw_opportunities.extend(opps)
                total_scraped += len(opps)
            except Exception as e:
                logger.error(f"Error in {scraper.name} scraper: {e}")

        logger.info(f"Total raw opportunities fetched across portals: {total_scraped}")

        # Step 2: Filter duplicates & perform AI evaluation
        for opp in all_raw_opportunities:
            unique_id = opp.get("unique_id")
            if not unique_id or self.db.lead_exists(unique_id):
                continue

            # Run AI Evaluation and Pitch Generation
            match_score, pitch_draft = self.ai.analyze_lead(opp)
            opp["match_score"] = match_score
            opp["pitch_draft"] = pitch_draft

            # Save to Database
            lead_id = self.db.save_lead(opp)
            if lead_id:
                new_leads_saved += 1
                logger.info(f"✨ New Lead [{match_score}% Match]: '{opp['title']}' at {opp['organization']}")

        logger.info(f"Saved {new_leads_saved} new unique leads into database.")

        # Step 3: Send notifications for qualified unnotified leads
        unnotified = self.db.get_unnotified_leads(min_score=50, limit=10)
        if unnotified:
            logger.info(f"Found {len(unnotified)} qualified leads pending notification...")
            for lead in unnotified:
                sent = self.notifier.send_lead_notification(lead)
                if sent:
                    self.db.mark_as_notified(lead["id"])
                    notified_count += 1
                    time.sleep(1.5)  # Telegram rate limit buffer
        else:
            logger.info("No unnotified leads pending for this cycle.")

        # Step 4: Generate/update HTML dashboard report
        all_leads = self.db.get_all_leads(limit=50)
        stats = self.db.get_stats()
        dashboard_path = generate_html_dashboard(all_leads, stats)

        logger.info(f"📊 Updated HTML Dashboard: file:///{dashboard_path.as_posix()}")
        logger.info(f"Cycle completed: {new_leads_saved} new leads found, {notified_count} sent to Telegram.")
        logger.info("=" * 60)

        return {
            "total_scraped": total_scraped,
            "new_leads_saved": new_leads_saved,
            "notified_count": notified_count,
            "dashboard_path": str(dashboard_path),
            "stats": stats
        }

    def start_background_daemon(self, interval_minutes: int = SCAN_INTERVAL_MINUTES):
        """Continuously runs the scan cycle at regular intervals."""
        logger.info(f"Starting Agent in continuous background mode (Interval: every {interval_minutes} minutes)...")
        # Run immediately on launch
        self.run_cycle()

        import schedule
        schedule.every(interval_minutes).minutes.do(self.run_cycle)

        while True:
            schedule.run_pending()
            time.sleep(10)


def main():
    parser = argparse.ArgumentParser(description="Autonomous Freelance Lead Generation AI Agent")
    parser.add_argument("--once", action="store_true", help="Run a single scan cycle and exit")
    parser.add_argument("--test-tg", action="store_true", help="Test Telegram Bot token and send a test message")
    parser.add_argument("--report", action="store_true", help="Generate HTML dashboard report")
    parser.add_argument("--stats", action="store_true", help="Display current lead statistics")
    parser.add_argument("--interval", type=int, default=SCAN_INTERVAL_MINUTES, help="Interval in minutes for continuous mode")

    args = parser.parse_args()
    agent = FreelanceAIAgent()

    if args.test_tg:
        print("\nTesting Telegram connection...")
        result = agent.notifier.test_connection()
        if result.get("ok"):
            print(f"SUCCESS: Connected to @{result.get('bot_username')}. Test message delivered to your chat!")
        else:
            print(f"ERROR: {result.get('error')}")
        return

    if args.stats:
        stats = agent.db.get_stats()
        print("\n--- Current Lead Statistics ---")
        for k, v in stats.items():
            print(f"{k}: {v}")
        return

    if args.report:
        leads = agent.db.get_all_leads()
        stats = agent.db.get_stats()
        path = generate_html_dashboard(leads, stats)
        print(f"\nDashboard updated: file:///{path.as_posix()}")
        return

    if args.once:
        agent.run_cycle()
    else:
        agent.start_background_daemon(interval_minutes=args.interval)


if __name__ == "__main__":
    main()
