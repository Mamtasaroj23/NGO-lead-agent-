Set WshShell = CreateObject("WScript.Shell")
' Run the agent completely hidden in the background (0 = hide window)
WshShell.Run "python run_agent.py", 0, False
Set WshShell = Nothing
