import logging
from abc import ABC, abstractmethod
from typing import List, Dict, Any

logger = logging.getLogger(__name__)

class BaseScraper(ABC):
    """Abstract base class for all freelance/volunteer opportunity scrapers."""

    def __init__(self, name: str):
        self.name = name
        self.default_headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
            'Accept': 'application/json, text/html, */*',
            'Accept-Language': 'en-US,en;q=0.9',
        }

    @abstractmethod
    def fetch_opportunities(self) -> List[Dict[str, Any]]:
        """Fetch and return a list of standardized opportunity dicts.
        
        Standard dictionary format:
        {
            "unique_id": "source_12345",
            "source": "Catchafire",
            "title": "Data Analysis & Donor Reporting",
            "organization": "Wildlife Trust",
            "cause": "Environment",
            "description": "...",
            "url": "https://...",
            "contact_person": "...",
        }
        """
        pass
