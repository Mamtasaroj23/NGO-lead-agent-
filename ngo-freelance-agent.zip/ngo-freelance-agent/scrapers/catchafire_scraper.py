import logging
import requests
from typing import List, Dict, Any
from scrapers.base_scraper import BaseScraper
from config import TARGET_KEYWORDS

logger = logging.getLogger(__name__)

class CatchafireScraper(BaseScraper):
    """Scrapes skills-based non-profit freelance projects from Catchafire."""

    def __init__(self):
        super().__init__("Catchafire")
        self.api_url = "https://www.catchafire.org/volunteer/api/projects/?page_size=30"

    def fetch_opportunities(self) -> List[Dict[str, Any]]:
        opportunities = []
        try:
            logger.info("Fetching volunteer projects from Catchafire API...")
            headers = dict(self.default_headers)
            headers['Referer'] = 'https://www.catchafire.org/volunteer/?type=1'
            headers['Accept'] = 'application/json, text/plain, */*'

            res = requests.get(self.api_url, headers=headers, timeout=20)
            if res.status_code != 200:
                logger.warning(f"Catchafire API error: {res.status_code}")
                return []

            data = res.json()
            results = data.get('results', [])

            for item in results:
                project_id = str(item.get('id', ''))
                if not project_id:
                    continue

                title = item.get('name') or item.get('title') or "Non-Profit Project"
                
                # Organization info
                nonprofit = item.get('nonprofit') or {}
                org_name = nonprofit.get('name') if isinstance(nonprofit, dict) else "Non-profit Organization"
                cause = nonprofit.get('primary_cause') if isinstance(nonprofit, dict) else "General"
                
                # Contact/Manager
                manager = item.get('volunteer_manager') or {}
                contact_name = manager.get('name', '') if isinstance(manager, dict) else ""

                # Description and details
                vol_desc = item.get('vol_description') or ""
                topic = item.get('topic') or ""
                impact = item.get('impact_statement') or ""
                
                full_description = f"{vol_desc} {topic} {impact}".strip()
                if not full_description:
                    full_description = "Help this organization with their mission-critical project."

                relative_url = item.get('url') or f"/volunteer/{project_id}/"
                full_url = f"https://www.catchafire.org{relative_url}"

                # Check relevance to data/business analyst or general tech/operations
                text_to_check = f"{title} {full_description} {cause}".lower()
                is_relevant = any(kw in text_to_check for kw in TARGET_KEYWORDS)

                # Prioritize matches, but also keep general projects if they need digital/reporting help
                opportunities.append({
                    "unique_id": f"catchafire_{project_id}",
                    "source": "Catchafire",
                    "title": title,
                    "organization": org_name,
                    "cause": cause,
                    "description": full_description,
                    "url": full_url,
                    "contact_person": contact_name,
                    "is_direct_data_match": is_relevant
                })

            logger.info(f"Catchafire: Discovered {len(opportunities)} total projects.")
            return opportunities

        except Exception as e:
            logger.error(f"Error scraping Catchafire: {e}")
            return []
