import logging
import re
import json
import requests
from typing import List, Dict, Any
from scrapers.base_scraper import BaseScraper
from config import TARGET_KEYWORDS

logger = logging.getLogger(__name__)

class IdealistScraper(BaseScraper):
    """Scrapes volunteer and freelancing listings from Idealist.org."""

    def __init__(self):
        super().__init__("Idealist")
        self.search_url = "https://www.idealist.org/en/volunteer?searchMode=true&q=data"

    def fetch_opportunities(self) -> List[Dict[str, Any]]:
        opportunities = []
        try:
            logger.info("Fetching opportunities from Idealist...")
            headers = dict(self.default_headers)
            headers['Referer'] = 'https://www.google.com/'

            res = requests.get(self.search_url, headers=headers, timeout=20)
            if res.status_code != 200:
                logger.warning(f"Idealist response status: {res.status_code}")
                return []

            html = res.text
            # Attempt to extract embedded NEXT_DATA
            next_data_match = re.search(r'<script[^>]*id="__NEXT_DATA__"[^>]*>(.*?)</script>', html, re.DOTALL)
            if next_data_match:
                try:
                    data = json.loads(next_data_match.group(1))
                    page_props = data.get('props', {}).get('pageProps', {})
                    # Look for search results
                    hits = page_props.get('results', []) or page_props.get('listings', []) or []
                    for h in hits:
                        item_id = str(h.get('id', ''))
                        title = h.get('name') or h.get('title') or "Data & Analytics Volunteer"
                        org = h.get('org', {}).get('name') if isinstance(h.get('org'), dict) else "Non-profit"
                        desc = h.get('description', '') or h.get('summary', '')
                        url = f"https://www.idealist.org/en/volunteer/{item_id}" if item_id else self.search_url
                        
                        opportunities.append({
                            "unique_id": f"idealist_{item_id or hash(title)}",
                            "source": "Idealist",
                            "title": title,
                            "organization": org,
                            "cause": "Social Impact",
                            "description": desc,
                            "url": url,
                            "contact_person": ""
                        })
                except Exception as json_err:
                    logger.debug(f"Could not parse Idealist NEXT_DATA: {json_err}")

            # Fallback regex extraction if NEXT_DATA was not present or empty
            if not opportunities:
                links = re.findall(r'href="(/en/volunteer/([^"]+))"[^>]*>(.*?)</a>', html)
                seen_ids = set()
                for rel_url, slug, anchor_text in links:
                    clean_id = slug.split('/')[0]
                    if clean_id not in seen_ids and len(clean_id) > 5:
                        seen_ids.add(clean_id)
                        opportunities.append({
                            "unique_id": f"idealist_{clean_id}",
                            "source": "Idealist",
                            "title": f"Volunteer Project ({clean_id.replace('-', ' ').title()})",
                            "organization": "Non-profit on Idealist",
                            "cause": "Community & Social Work",
                            "description": "Volunteer opportunity involving data, reporting, or community outreach.",
                            "url": f"https://www.idealist.org/en/volunteer/{clean_id}",
                            "contact_person": ""
                        })

            logger.info(f"Idealist: Discovered {len(opportunities)} opportunities.")
            return opportunities

        except Exception as e:
            logger.error(f"Error scraping Idealist: {e}")
            return []
