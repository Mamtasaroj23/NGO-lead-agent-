@echo off
title AI Freelance Lead Agent - Data & Business Analyst
cd /d "%~dp0"
echo ========================================================
echo   Autonomous AI Freelance Lead Agent
echo   Target: Data & Business Analyst Pro-Bono Leads
echo ========================================================
echo.
python run_agent.py
pause
