import sys
import json
import logging
import threading
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from pathlib import Path

# Ensure UTF-8 console output
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')
if hasattr(sys.stderr, 'reconfigure'):
    sys.stderr.reconfigure(encoding='utf-8')

from config import BASE_DIR, TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID, GEMINI_API_KEY
from core.database import LeadDatabase
from core.notifier import TelegramNotifier
from run_agent import FreelanceAIAgent

logger = logging.getLogger("WebServer")
db = LeadDatabase()
agent = FreelanceAIAgent()

import os
PORT = int(os.environ.get("PORT", 5000))

class DashboardHandler(BaseHTTPRequestHandler):
    def _set_headers(self, status=200, content_type="application/json"):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_OPTIONS(self):
        self._set_headers(200)

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path

        if path == "/" or path == "/index.html":
            self._serve_dashboard_html()
        elif path == "/api/leads":
            leads = db.get_all_leads(limit=100)
            self._set_headers(200)
            self.wfile.write(json.dumps(leads, default=str).encode("utf-8"))
        elif path == "/api/stats":
            stats = db.get_stats()
            self._set_headers(200)
            self.wfile.write(json.dumps(stats).encode("utf-8"))
        else:
            self._set_headers(404, "text/plain")
            self.wfile.write(b"Not Found")

    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path

        if path == "/api/scan":
            # Run scan in a background thread so UI doesn't freeze
            def scan_worker():
                agent.run_cycle()

            t = threading.Thread(target=scan_worker, daemon=True)
            t.start()
            self._set_headers(200)
            self.wfile.write(json.dumps({"status": "started", "message": "Scan started in background"}).encode("utf-8"))

        elif path == "/api/test-telegram":
            result = agent.notifier.test_connection()
            self._set_headers(200)
            self.wfile.write(json.dumps(result).encode("utf-8"))
        else:
            self._set_headers(404)
            self.wfile.write(b"Not Found")

    def _serve_dashboard_html(self):
        stats = db.get_stats()
        leads = db.get_all_leads(limit=100)
        leads_json = json.dumps(leads, default=str)
        stats_json = json.dumps(stats)

        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Freelance Lead Portal - Data & Business Analyst</title>
    <style>
        :root {{
            --bg-body: #0b1120;
            --bg-card: #1e293b;
            --bg-card-hover: #26354a;
            --accent: #38bdf8;
            --accent-hover: #0284c7;
            --success: #10b981;
            --warning: #f59e0b;
            --text-primary: #f8fafc;
            --text-secondary: #94a3b8;
            --border: #334155;
        }}
        * {{ box-sizing: border-box; }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
            background-color: var(--bg-body);
            color: var(--text-primary);
            margin: 0;
            padding: 0;
        }}
        .navbar {{
            background: rgba(15, 23, 42, 0.9);
            backdrop-filter: blur(12px);
            border-bottom: 1px solid var(--border);
            padding: 16px 32px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 50;
        }}
        .brand {{
            display: flex;
            align-items: center;
            gap: 12px;
        }}
        .brand h1 {{
            font-size: 20px;
            margin: 0;
            color: var(--accent);
            font-weight: 700;
        }}
        .badge-role {{
            background: #1e3a8a;
            color: #93c5fd;
            font-size: 11px;
            padding: 3px 8px;
            border-radius: 6px;
            font-weight: 600;
        }}
        .nav-actions {{
            display: flex;
            align-items: center;
            gap: 12px;
        }}
        .btn {{
            padding: 8px 16px;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            border: none;
            transition: all 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }}
        .btn-primary {{
            background: var(--accent);
            color: #0b1120;
        }}
        .btn-primary:hover {{
            background: var(--accent-hover);
            color: white;
        }}
        .btn-secondary {{
            background: #334155;
            color: var(--text-primary);
        }}
        .btn-secondary:hover {{
            background: #475569;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
            padding: 32px 24px;
        }}
        .stats-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
            margin-bottom: 32px;
        }}
        .stat-card {{
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 20px;
            position: relative;
            overflow: hidden;
        }}
        .stat-val {{
            font-size: 32px;
            font-weight: 800;
            color: var(--accent);
            margin-bottom: 4px;
        }}
        .stat-label {{
            color: var(--text-secondary);
            font-size: 13px;
            font-weight: 500;
        }}
        .toolbar {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
            flex-wrap: wrap;
            gap: 16px;
        }}
        .search-box {{
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: 8px;
            padding: 10px 14px;
            color: white;
            font-size: 14px;
            width: 320px;
            max-width: 100%;
        }}
        .search-box:focus {{
            outline: none;
            border-color: var(--accent);
        }}
        .filter-tags {{
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }}
        .filter-tag {{
            background: var(--bg-card);
            border: 1px solid var(--border);
            padding: 6px 14px;
            border-radius: 20px;
            font-size: 12px;
            cursor: pointer;
            transition: all 0.15s;
        }}
        .filter-tag.active {{
            background: var(--accent);
            color: #0b1120;
            font-weight: 600;
            border-color: var(--accent);
        }}
        .leads-grid {{
            display: grid;
            grid-template-columns: 1fr;
            gap: 20px;
        }}
        .card {{
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: 14px;
            padding: 24px;
            transition: transform 0.15s, border-color 0.15s;
        }}
        .card:hover {{
            border-color: #475569;
        }}
        .card-top {{
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 16px;
            margin-bottom: 12px;
        }}
        .badges {{
            display: flex;
            gap: 8px;
            align-items: center;
            margin-bottom: 8px;
        }}
        .badge-source {{
            background: #2563eb;
            color: white;
            font-size: 11px;
            padding: 3px 8px;
            border-radius: 4px;
            font-weight: 600;
            text-transform: uppercase;
        }}
        .badge-match {{
            font-size: 12px;
            padding: 3px 10px;
            border-radius: 999px;
            font-weight: 700;
            color: #0b1120;
        }}
        .lead-title {{
            font-size: 20px;
            margin: 0 0 6px 0;
            color: #f8fafc;
            font-weight: 700;
        }}
        .lead-org {{
            color: var(--text-secondary);
            font-size: 14px;
            margin: 0;
        }}
        .lead-org strong {{
            color: #cbd5e1;
        }}
        .lead-desc {{
            color: #cbd5e1;
            font-size: 14px;
            line-height: 1.6;
            margin: 16px 0;
        }}
        .pitch-box {{
            background: #0f172a;
            border: 1px solid var(--border);
            border-radius: 10px;
            padding: 16px;
            margin-top: 16px;
        }}
        .pitch-box-header {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
            font-size: 13px;
            font-weight: 600;
            color: var(--accent);
        }}
        .pitch-content {{
            font-family: inherit;
            white-space: pre-wrap;
            font-size: 13px;
            color: #e2e8f0;
            line-height: 1.6;
            margin: 0;
        }}
        .apply-link {{
            background: #2563eb;
            color: white;
            text-decoration: none;
            padding: 8px 16px;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            white-space: nowrap;
        }}
        .apply-link:hover {{
            background: #1d4ed8;
        }}
        .toast {{
            position: fixed;
            bottom: 24px;
            right: 24px;
            background: #10b981;
            color: white;
            padding: 12px 20px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            display: none;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.3);
            z-index: 100;
        }}
    </style>
</head>
<body>
    <div class="navbar">
        <div class="brand">
            <h1>⚡ AI Lead Hunter</h1>
            <span class="badge-role">Data &amp; Business Analyst</span>
        </div>
        <div class="nav-actions">
            <button class="btn btn-secondary" onclick="testTelegram()">📱 Test Telegram</button>
            <button class="btn btn-primary" onclick="triggerScan()">🔄 Scan For New Leads</button>
        </div>
    </div>

    <div class="container">
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-val" id="stat-total">{stats.get('total_leads', 0)}</div>
                <div class="stat-label">Total Leads Discovered</div>
            </div>
            <div class="stat-card">
                <div class="stat-val" id="stat-high" style="color: #10b981;">{stats.get('high_match_leads', 0)}</div>
                <div class="stat-label">High Match (80%+)</div>
            </div>
            <div class="stat-card">
                <div class="stat-val" id="stat-notified" style="color: #38bdf8;">{stats.get('notified_leads', 0)}</div>
                <div class="stat-label">Sent to Telegram</div>
            </div>
            <div class="stat-card">
                <div class="stat-val" style="color: #f59e0b;">100% Free</div>
                <div class="stat-label">Pro-Bono Outreach</div>
            </div>
        </div>

        <div class="toolbar">
            <input type="text" id="searchInput" class="search-box" placeholder="🔍 Search organization, skill, or project..." oninput="filterLeads()">
            <div class="filter-tags">
                <div class="filter-tag active" onclick="setFilter('all', this)">All Leads</div>
                <div class="filter-tag" onclick="setFilter('high', this)">High Match (80%+)</div>
                <div class="filter-tag" onclick="setFilter('Catchafire', this)">Catchafire</div>
                <div class="filter-tag" onclick="setFilter('NGO Darpan', this)">NGO Darpan (India)</div>
            </div>
        </div>

        <div class="leads-grid" id="leadsGrid"></div>
    </div>

    <div class="toast" id="toast">Copied to clipboard!</div>

    <script>
        const leadsData = {leads_json};
        let currentFilter = 'all';

        function showToast(msg) {{
            const t = document.getElementById('toast');
            t.innerText = msg;
            t.style.display = 'block';
            setTimeout(() => {{ t.style.display = 'none'; }}, 2500);
        }}

        function setFilter(filter, el) {{
            currentFilter = filter;
            document.querySelectorAll('.filter-tag').forEach(t => t.classList.remove('active'));
            el.classList.add('active');
            filterLeads();
        }}

        function filterLeads() {{
            const query = document.getElementById('searchInput').value.toLowerCase();
            const grid = document.getElementById('leadsGrid');
            grid.innerHTML = '';

            const filtered = leadsData.filter(l => {{
                // Filter tag match
                if (currentFilter === 'high' && (l.match_score || 0) < 80) return false;
                if (currentFilter === 'Catchafire' && !l.source.includes('Catchafire')) return false;
                if (currentFilter === 'NGO Darpan' && !l.source.includes('NGO Darpan')) return false;

                // Search query match
                const matchText = (l.title + ' ' + l.organization + ' ' + l.cause + ' ' + l.description).toLowerCase();
                return matchText.includes(query);
            }});

            if (filtered.length === 0) {{
                grid.innerHTML = '<p style="text-align:center; color:#94a3b8; padding: 40px;">No matching opportunities found. Click "Scan For New Leads" to fetch more!</p>';
                return;
            }}

            filtered.forEach(l => {{
                const score = l.match_score || 50;
                const scoreColor = score >= 80 ? '#10b981' : (score >= 60 ? '#f59e0b' : '#64748b');
                
                const card = document.createElement('div');
                card.className = 'card';
                card.innerHTML = `
                    <div class="card-top">
                        <div>
                            <div class="badges">
                                <span class="badge-source">${{l.source}}</span>
                                <span class="badge-match" style="background:${{scoreColor}}">${{score}}% Skill Match</span>
                            </div>
                            <h2 class="lead-title">${{l.title}}</h2>
                            <p class="lead-org">🏢 <strong>${{l.organization}}</strong> &bull; ${{l.cause}}</p>
                        </div>
                        <a href="${{l.url}}" target="_blank" class="apply-link">View Opportunity &rarr;</a>
                    </div>
                    <p class="lead-desc">${{l.description || 'Pro-bono data analysis and reporting opportunity.'}}</p>
                    <div class="pitch-box">
                        <div class="pitch-box-header">
                            <span>💌 Personalized Outreach Pitch (Ready to Send)</span>
                            <button class="btn btn-secondary" style="padding:4px 10px; font-size:12px;" onclick="copyPitch(this)">📋 Copy Pitch</button>
                        </div>
                        <pre class="pitch-content">${{l.pitch_draft || ''}}</pre>
                    </div>
                `;
                grid.appendChild(card);
            }});
        }}

        function copyPitch(btn) {{
            const pitch = btn.closest('.pitch-box').querySelector('.pitch-content').innerText;
            navigator.clipboard.writeText(pitch);
            btn.innerText = '✅ Copied!';
            showToast('Pitch copied to clipboard!');
            setTimeout(() => {{ btn.innerText = '📋 Copy Pitch'; }}, 2000);
        }}

        async function triggerScan() {{
            showToast('⏳ Initiating live background scan across portals...');
            try {{
                const res = await fetch('/api/scan', {{ method: 'POST' }});
                const data = await res.json();
                showToast('🚀 Scan started! Refreshing in 10s...');
                setTimeout(() => location.reload(), 10000);
            }} catch(e) {{
                showToast('❌ Scan failed: ' + e);
            }}
        }}

        async function testTelegram() {{
            showToast('📱 Sending test message to Telegram...');
            try {{
                const res = await fetch('/api/test-telegram', {{ method: 'POST' }});
                const data = await res.json();
                if (data.ok) {{
                    showToast('✅ Success! Message sent to Telegram.');
                }} else {{
                    alert('Telegram Test Result:\n' + data.error);
                }}
            }} catch(e) {{
                showToast('❌ Error: ' + e);
            }}
        }}

        // Initial render
        filterLeads();
    </script>
</body>
</html>
"""
        self._set_headers(200, "text/html; charset=utf-8")
        self.wfile.write(html.encode("utf-8"))


def run_server(port=PORT):
    server = HTTPServer(("0.0.0.0", port), DashboardHandler)
    print(f"=======================================================")
    print(f"  AI Freelance Lead Portal is LIVE on Localhost!")
    print(f"  👉 Open URL: http://localhost:{port}")
    print(f"=======================================================")
    server.serve_forever()

if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else PORT
    run_server(port)
